from .conversion import convert_as_pattern, convert_as_bin_mat
