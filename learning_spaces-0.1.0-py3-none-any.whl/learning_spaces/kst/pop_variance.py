import numpy as np


def pop_variance():

    return {}