import numpy as np
import pandas as pd


def pattern(dataset, n = 5, p = None):

    return {}

