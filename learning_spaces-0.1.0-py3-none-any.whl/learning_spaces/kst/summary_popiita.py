import numpy as np


def summary_popiita(obj):
    return {'value': obj, 'class_name': "sumpopiita"}